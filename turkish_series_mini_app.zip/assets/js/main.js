
fetch("data/series.json")
  .then(res => res.json())
  .then(data => {
    const container = document.getElementById("series-container");
    data.forEach(series => {
      const card = document.createElement("div");
      card.className = "series-card";
      card.innerHTML = `
        <img src="${series.poster}" alt="${series.title}">
        <h3>${series.title}</h3>
        <a href="series-template.html?slug=${series.slug}">Watch</a>
      `;
      container.appendChild(card);
    });
  });
